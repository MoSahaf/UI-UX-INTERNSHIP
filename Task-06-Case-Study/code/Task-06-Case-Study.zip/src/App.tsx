import { useState } from 'react'

// ─── Palette constants ────────────────────────────────────────────────────────
const V = '#A855F7'   // violet primary
const C = '#06B6D4'   // cyan accent
const CO = '#F97316'  // coral
const PK = '#EC4899'  // pink
const LM = '#84CC16'  // lime

// ─── Data ────────────────────────────────────────────────────────────────────
const NAV_SECTIONS = [
  { id: 'overview', label: 'Overview' },
  { id: 'research', label: 'Research' },
  { id: 'personas', label: 'Personas' },
  { id: 'journey', label: 'Journey' },
  { id: 'wireframes', label: 'Wireframes' },
  { id: 'system', label: 'Design System' },
  { id: 'hifi', label: 'Hi-Fi' },
  { id: 'prototype', label: 'Prototype' },
  { id: 'outcomes', label: 'Outcomes' },
]

const COMPETITORS = [
  { name: 'Notion', strengths: ['Flexible', 'Rich embeds', 'Collaboration'], weaknesses: ['Steep learning', 'No chat', 'Slow mobile'], nps: 52, mau: '30M', color: '#F97316' },
  { name: 'Linear', strengths: ['Keyboard-first', 'Speed', 'Dev-loved'], weaknesses: ['Limited custom', 'No docs', 'Single persona'], nps: 71, mau: '4M', color: '#A855F7' },
  { name: 'Jira', strengths: ['Enterprise', 'Integrations', 'Audit trail'], weaknesses: ['Complex config', 'Poor UX', 'High latency'], nps: 18, mau: '65M', color: '#EC4899' },
  { name: 'Asana', strengths: ['Timeline', 'Onboarding', 'Visual polish'], weaknesses: ['Pricing tiers', 'Limited API', 'No offline'], nps: 44, mau: '13M', color: '#06B6D4' },
]

const PERSONAS = [
  {
    id: 'A', name: 'Maya Okonkwo', role: 'Senior Product Manager', age: 34, location: 'London, UK',
    quote: '"I need one place where strategy and execution aren\'t ten clicks apart."',
    goals: ['Ship features faster', 'Cut status meeting overhead', 'Align eng & design'],
    frustrations: ['Context-switching between tools', 'Stale roadmap docs', 'Missing notifications'],
    tools: ['Notion', 'Jira', 'Slack', 'Figma'],
    photo: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=400&h=400&fit=crop&auto=format',
    color: V, glow: 'rgba(168,85,247,0.25)',
  },
  {
    id: 'B', name: 'Daniel Reyes', role: 'Staff Engineer', age: 29, location: 'São Paulo, BR',
    quote: '"I want to understand the why behind a ticket without reading three PRDs."',
    goals: ['Ship with confidence', 'Reduce ambiguity', 'Async-first workflow'],
    frustrations: ['No-context tickets', 'Stale Figma links', 'Long sync meetings'],
    tools: ['Linear', 'GitHub', 'Slack', 'VS Code'],
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&auto=format',
    color: C, glow: 'rgba(6,182,212,0.25)',
  },
  {
    id: 'C', name: 'Priya Sharma', role: 'UX Designer', age: 27, location: 'Bangalore, IN',
    quote: '"I lose hours reconciling what got built versus what we designed."',
    goals: ['Design-dev parity', 'Faster feedback loops', 'Component reuse tracking'],
    frustrations: ['No source of truth', 'Last-minute scope changes', 'Specs no one reads'],
    tools: ['Figma', 'Notion', 'Zeplin', 'Miro'],
    photo: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop&auto=format',
    color: PK, glow: 'rgba(236,72,153,0.25)',
  },
]

const JOURNEY_STAGES = [
  { stage: 'Discover', action: 'Sees ad on LinkedIn or gets referred by a colleague', emotion: 3, pm: 'Wants quick signup, no demo call', eng: 'Skeptical — another PM tool?', des: 'Excited by Figma plugin' },
  { stage: 'Sign Up', action: 'Creates account, invites team, links GitHub repo', emotion: 4, pm: 'Needs onboarding in < 5 min', eng: 'Checks if there\'s an API key', des: 'Looks for Figma integration first' },
  { stage: 'First Use', action: 'Creates a roadmap, imports existing tickets', emotion: 2, pm: 'Frustrated by blank-slate moment', eng: 'Wants CLI, not a web form', des: 'Imports components from Figma' },
  { stage: 'Daily Work', action: 'Updates statuses, leaves comments, links PRs', emotion: 5, pm: 'Weekly review dashboard is key', eng: 'PR ↔ ticket linking is the hook', des: 'Design handoff annotations' },
  { stage: 'Collaborate', action: 'Shares roadmap view with stakeholders', emotion: 4, pm: 'Public read-only roadmap link', eng: 'Code review + ticket in one pane', des: 'Comments on spec screen' },
  { stage: 'Advocate', action: 'Refers colleagues, leaves G2 review', emotion: 5, pm: 'Brings in other PMs at company', eng: 'Writes blog post about workflow', des: 'Posts Figma plugin on Twitter' },
]

const COLORS = [
  { name: 'Violet', hex: '#A855F7', role: 'Primary / CTA' },
  { name: 'Cyan', hex: '#06B6D4', role: 'Accent / Links' },
  { name: 'Coral', hex: '#F97316', role: 'Warning / Highlight' },
  { name: 'Pink', hex: '#EC4899', role: 'Personas / Tags' },
  { name: 'Lime', hex: '#84CC16', role: 'Success / Shipped' },
  { name: 'Deep Navy', hex: '#07050F', role: 'Background' },
  { name: 'Slate Card', hex: '#0F0B1E', role: 'Card surface' },
  { name: 'Mist', hex: '#F0EDFF', role: 'Foreground text' },
]

const TYPE_SCALE = [
  { label: 'Display', size: 56, weight: '300', style: 'italic', family: 'Fraunces', sample: 'One tool, one truth.' },
  { label: 'H1', size: 36, weight: '400', style: 'normal', family: 'Fraunces', sample: 'The research phase' },
  { label: 'H2', size: 24, weight: '700', style: 'normal', family: 'Inter', sample: 'Competitor analysis' },
  { label: 'Body', size: 15, weight: '400', style: 'normal', family: 'Inter', sample: 'Participants rated task clarity on a 5-point Likert scale.' },
  { label: 'Label', size: 10, weight: '400', style: 'normal', family: 'JetBrains Mono', sample: 'SECTION_01 / RESEARCH' },
]

const HIFI_SCREENS = [
  { id: 1, title: 'Dashboard — Command Center', desc: 'Weekly pulse: velocity, blockers, and shipped items across all active tracks.', tag: 'OVERVIEW', bg: 'linear-gradient(135deg,#1a0a2e 0%,#0d1a3a 100%)', accent: V },
  { id: 2, title: 'Roadmap Timeline', desc: 'Drag-to-reorder quarters with dependency lines and milestone markers.', tag: 'PLANNING', bg: 'linear-gradient(135deg,#051a1e 0%,#0a1520 100%)', accent: C },
  { id: 3, title: 'Ticket + Spec Pane', desc: 'A single pane with the PRD, design frame, and linked PR status.', tag: 'EXECUTION', bg: 'linear-gradient(135deg,#1e0516 0%,#1a0820 100%)', accent: PK },
  { id: 4, title: 'Design Handoff Overlay', desc: 'Annotations, redlines, and component links pulled live from Figma.', tag: 'HANDOFF', bg: 'linear-gradient(135deg,#071a07 0%,#0a1a15 100%)', accent: LM },
]

const METRICS = [
  { label: 'Task completion rate', before: '61%', after: '89%', delta: '+28pp', pct: 89 },
  { label: 'Time to first update', before: '4.2 days', after: '1.1 days', delta: '−73%', pct: 74 },
  { label: 'Sync meetings / sprint', before: '6.4', after: '3.1', delta: '−52%', pct: 52 },
  { label: 'Design-dev parity score', before: '54/100', after: '81/100', delta: '+27pts', pct: 81 },
  { label: 'Pilot NPS', before: '−12', after: '+58', delta: '+70', pct: 79 },
]

// ─── Helpers ─────────────────────────────────────────────────────────────────

function GlowBadge({ label, color }: { label: string; color: string }) {
  return (
    <span className="inline-block font-mono text-[9px] tracking-widest px-2 py-0.5 rounded-full border"
      style={{ color, borderColor: `${color}50`, background: `${color}12` }}>
      {label}
    </span>
  )
}

function SectionLabel({ number, title, color = V }: { number: string; title: string; color?: string }) {
  return (
    <div className="flex items-center gap-3 mb-10">
      <span className="font-mono text-[9px] tracking-[0.3em]" style={{ color }}>{number}</span>
      <div className="h-px flex-1" style={{ background: `linear-gradient(to right, ${color}40, transparent)` }} />
      <span className="font-mono text-[9px] tracking-[0.25em] uppercase" style={{ color }}>{title}</span>
    </div>
  )
}

function Section({ id, children }: { id: string; children: React.ReactNode }) {
  return (
    <section id={id} className="py-20 border-b" style={{ borderColor: 'rgba(168,85,247,0.08)' }}>
      {children}
    </section>
  )
}

function EmotionBar({ level }: { level: number }) {
  const c = level <= 2 ? '#EF4444' : level === 3 ? '#F97316' : level === 4 ? '#06B6D4' : '#84CC16'
  return (
    <div className="flex items-center gap-0.5">
      {[1,2,3,4,5].map(i => (
        <div key={i} className="h-2 rounded-full transition-all" style={{ width: i <= level ? 16 : 8, background: i <= level ? c : 'rgba(255,255,255,0.08)' }} />
      ))}
    </div>
  )
}

// ─── Main ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [activeNav, setActiveNav] = useState('overview')
  const [navOpen, setNavOpen] = useState(false)
  const [activePersona, setActivePersona] = useState(0)
  const [activeScreen, setActiveScreen] = useState(0)
  const [protoStep, setProtoStep] = useState(0)
  const [researchTab, setResearchTab] = useState<'findings' | 'competitors'>('findings')

  const scrollTo = (id: string) => {
    setActiveNav(id)
    setNavOpen(false)
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <div className="min-h-screen" style={{ background: '#07050F', color: '#F0EDFF' }}>

      {/* ── Nav ── */}
      <nav className="fixed top-0 inset-x-0 z-50 border-b" style={{ background: 'rgba(7,5,15,0.85)', backdropFilter: 'blur(16px)', borderColor: 'rgba(168,85,247,0.15)' }}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-14">

          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg,#A855F7,#06B6D4)' }}>
              <span className="text-white font-bold text-xs">F</span>
            </div>
            <span className="font-mono text-[11px] tracking-[0.15em]" style={{ color: V }}>FLUX CASE STUDY</span>
          </div>

          <div className="hidden lg:flex items-center gap-1">
            {NAV_SECTIONS.map(s => (
              <button key={s.id} onClick={() => scrollTo(s.id)}
                className="font-mono text-[10px] tracking-wider px-3 py-1.5 rounded-md transition-all"
                style={{ color: activeNav === s.id ? '#fff' : '#7C6FA8', background: activeNav === s.id ? `${V}20` : 'transparent' }}>
                {s.label}
              </button>
            ))}
          </div>

          <button className="lg:hidden font-mono text-[10px] tracking-widest" style={{ color: V }}
            onClick={() => setNavOpen(!navOpen)}>
            {navOpen ? '✕ CLOSE' : '≡ MENU'}
          </button>
        </div>
        {navOpen && (
          <div className="lg:hidden px-6 py-4 grid grid-cols-3 gap-2" style={{ background: 'rgba(7,5,15,0.98)', borderTop: `1px solid rgba(168,85,247,0.12)` }}>
            {NAV_SECTIONS.map(s => (
              <button key={s.id} onClick={() => scrollTo(s.id)}
                className="font-mono text-[10px] py-2 rounded-md text-center tracking-wider"
                style={{ color: activeNav === s.id ? '#fff' : '#7C6FA8', background: activeNav === s.id ? `${V}20` : 'rgba(168,85,247,0.05)' }}>
                {s.label}
              </button>
            ))}
          </div>
        )}
      </nav>

      <main className="max-w-7xl mx-auto px-6 pt-14">

        {/* ── 00 OVERVIEW ── */}
        <Section id="overview">
          <div className="pt-16">

            {/* Hero */}
            <div className="relative mb-12 overflow-hidden rounded-2xl" style={{ background: 'linear-gradient(135deg,#1a0533 0%,#050d2e 50%,#001a1a 100%)' }}>
              {/* Orbs */}
              <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full pointer-events-none" style={{ background: 'radial-gradient(circle,rgba(168,85,247,0.25) 0%,transparent 70%)', filter: 'blur(40px)' }} />
              <div className="absolute bottom-0 right-1/4 w-80 h-80 rounded-full pointer-events-none" style={{ background: 'radial-gradient(circle,rgba(6,182,212,0.2) 0%,transparent 70%)', filter: 'blur(40px)' }} />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full pointer-events-none" style={{ background: 'radial-gradient(circle,rgba(236,72,153,0.12) 0%,transparent 70%)', filter: 'blur(40px)' }} />

              <div className="relative px-10 py-16">
                <div className="flex items-center gap-2 mb-6">
                  <GlowBadge label="PRODUCT DESIGN" color={V} />
                  <GlowBadge label="UX CASE STUDY" color={C} />
                  <GlowBadge label="2024" color={CO} />
                </div>
                <h1 className="font-serif text-6xl md:text-8xl font-light italic mb-6 leading-[0.9]"
                  style={{ background: 'linear-gradient(135deg,#F0EDFF 0%,#C4B5FD 40%,#67E8F9 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
                  One tool,<br />one truth.
                </h1>
                <p className="font-serif text-xl italic text-[#C4B5FD] max-w-xl leading-relaxed mb-10">
                  Designing <em style={{ color: V }}>Flux</em> — a unified product workspace that ends the context-switching tax for modern product teams.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[['14 weeks','Timeline'],['18 users','Interviews'],['47 screens','Hi-Fi'],['Lead Designer','Role']].map(([val,lbl]) => (
                    <div key={lbl} className="rounded-xl p-4 border" style={{ background: 'rgba(168,85,247,0.08)', borderColor: 'rgba(168,85,247,0.2)' }}>
                      <p className="font-serif text-2xl font-light" style={{ color: V }}>{val}</p>
                      <p className="font-mono text-[9px] tracking-wider text-[#7C6FA8] mt-1">{lbl.toUpperCase()}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Problem statement */}
            <div className="grid md:grid-cols-3 gap-4">
              {[
                { icon: '🔀', title: 'Context overload', body: 'The average PM switches between 7 tools per day. Each switch costs cognitive bandwidth and creates coordination gaps.', color: V },
                { icon: '🕳️', title: 'The handoff gap', body: 'Engineers say 61% of Figma specs they receive don\'t match what ultimately gets merged into production.', color: C },
                { icon: '📉', title: 'Strategy drift', body: 'Only 29% of engineers know the "why" behind the ticket they\'re currently building without opening a separate doc.', color: PK },
              ].map(c => (
                <div key={c.title} className="rounded-xl p-5 border group hover:scale-[1.02] transition-transform" style={{ background: 'rgba(255,255,255,0.02)', borderColor: `${c.color}25` }}>
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center mb-4 text-xl" style={{ background: `${c.color}18` }}>{c.icon}</div>
                  <h3 className="font-serif text-lg mb-2" style={{ color: c.color }}>{c.title}</h3>
                  <p className="text-sm text-[#C4B5FD] leading-relaxed">{c.body}</p>
                </div>
              ))}
            </div>
          </div>
        </Section>

        {/* ── 01 RESEARCH ── */}
        <Section id="research">
          <SectionLabel number="01" title="User & Competitor Research" color={C} />

          <div className="grid md:grid-cols-5 gap-8 mb-10">
            <div className="md:col-span-3">
              <h2 className="font-serif text-4xl font-light mb-4" style={{ color: '#F0EDFF' }}>Research methodology</h2>
              <p className="text-[#C4B5FD] text-sm leading-relaxed mb-6">
                A 6-week mixed-methods sprint: semi-structured interviews, diary studies, and a quantitative survey (n=214). Goal: map the exact moments where coordination overhead breaks down.
              </p>
              <div className="space-y-2">
                {[
                  { method: 'Contextual interviews', n: 18, duration: '60–90 min', color: V },
                  { method: 'Diary study participants', n: 12, duration: '2 weeks', color: C },
                  { method: 'Survey respondents', n: 214, duration: 'Async', color: PK },
                  { method: 'Usability sessions', n: 8, duration: '45 min', color: CO },
                ].map(r => (
                  <div key={r.method} className="flex items-center justify-between rounded-lg px-4 py-3 border" style={{ background: `${r.color}08`, borderColor: `${r.color}20` }}>
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full" style={{ background: r.color }} />
                      <span className="text-sm text-[#F0EDFF]">{r.method}</span>
                    </div>
                    <div className="flex gap-4">
                      <span className="font-mono text-xs" style={{ color: r.color }}>n={r.n}</span>
                      <span className="font-mono text-xs text-[#7C6FA8]">{r.duration}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="md:col-span-2 grid grid-cols-1 gap-3">
              {[
                { stat: '73%', label: 'use 5+ tools daily', color: V, icon: '🔄' },
                { stat: '2.4h', label: 'lost to context-switching per day', color: C, icon: '⏱️' },
                { stat: '61%', label: 'say design specs are stale', color: PK, icon: '📋' },
                { stat: '82%', label: 'disable notifications weekly', color: CO, icon: '🔕' },
              ].map(s => (
                <div key={s.stat} className="flex items-center gap-4 rounded-xl p-4 border" style={{ background: `${s.color}08`, borderColor: `${s.color}25` }}>
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0" style={{ background: `${s.color}15` }}>{s.icon}</div>
                  <div>
                    <p className="font-serif text-3xl font-light" style={{ color: s.color }}>{s.stat}</p>
                    <p className="text-xs text-[#7C6FA8]">{s.label}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mb-6">
            {(['findings', 'competitors'] as const).map(tab => (
              <button key={tab} onClick={() => setResearchTab(tab)}
                className="font-mono text-[10px] tracking-widest px-4 py-2 rounded-full border transition-all"
                style={{
                  color: researchTab === tab ? '#fff' : '#7C6FA8',
                  borderColor: researchTab === tab ? V : 'rgba(168,85,247,0.2)',
                  background: researchTab === tab ? `linear-gradient(135deg,${V},${C})` : 'transparent',
                }}>
                {tab === 'findings' ? 'KEY FINDINGS' : 'COMPETITIVE MATRIX'}
              </button>
            ))}
          </div>

          {researchTab === 'findings' && (
            <div className="grid md:grid-cols-2 gap-4">
              {[
                { insight: 'The handoff gap', body: 'Engineers say specs drift after design review. 61% say the Figma file they receive doesn\'t match what gets merged.', tag: 'DESIGN–ENG', color: V },
                { insight: 'Meeting overhead', body: 'Teams with poor async tooling hold 6.4 syncs per sprint (×45 min each). The drag is visible in every velocity chart.', tag: 'PROCESS', color: C },
                { insight: 'Notification fatigue', body: '82% of PMs disable Slack notifications weekly. Signal-to-noise across tools creates learned helplessness.', tag: 'COMM', color: PK },
                { insight: 'Strategy invisibility', body: 'Only 29% of engineers know the "why" behind their current ticket without opening a separate document.', tag: 'ALIGNMENT', color: CO },
              ].map(f => (
                <div key={f.insight} className="rounded-xl p-5 border hover:scale-[1.01] transition-transform" style={{ background: `${f.color}06`, borderColor: `${f.color}25` }}>
                  <GlowBadge label={f.tag} color={f.color} />
                  <h3 className="font-serif text-xl mt-3 mb-2" style={{ color: f.color }}>{f.insight}</h3>
                  <p className="text-sm text-[#C4B5FD] leading-relaxed">{f.body}</p>
                </div>
              ))}
            </div>
          )}

          {researchTab === 'competitors' && (
            <div className="grid md:grid-cols-2 gap-4">
              {COMPETITORS.map(c => (
                <div key={c.name} className="rounded-xl p-5 border" style={{ background: `${c.color}06`, borderColor: `${c.color}25` }}>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-serif text-2xl font-light" style={{ color: c.color }}>{c.name}</h3>
                    <div className="text-right">
                      <p className="font-mono text-xs text-[#7C6FA8]">NPS</p>
                      <p className="font-mono text-lg font-medium" style={{ color: c.nps > 50 ? LM : c.nps > 30 ? CO : '#EF4444' }}>
                        {c.nps > 0 ? '+' : ''}{c.nps}
                      </p>
                    </div>
                  </div>
                  <div className="mb-3">
                    <p className="font-mono text-[9px] tracking-wider text-[#7C6FA8] mb-2">STRENGTHS</p>
                    <div className="flex flex-wrap gap-1">
                      {c.strengths.map(s => <GlowBadge key={s} label={s} color={LM} />)}
                    </div>
                  </div>
                  <div>
                    <p className="font-mono text-[9px] tracking-wider text-[#7C6FA8] mb-2">GAPS</p>
                    <div className="flex flex-wrap gap-1">
                      {c.weaknesses.map(w => <GlowBadge key={w} label={w} color="#EF4444" />)}
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t flex justify-between" style={{ borderColor: `${c.color}20` }}>
                    <span className="font-mono text-[9px] text-[#7C6FA8]">MAU</span>
                    <span className="font-mono text-xs" style={{ color: c.color }}>{c.mau}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Section>

        {/* ── 02 PERSONAS ── */}
        <Section id="personas">
          <SectionLabel number="02" title="Personas" color={V} />

          <div className="flex gap-2 mb-8 flex-wrap">
            {PERSONAS.map((p, i) => (
              <button key={p.id} onClick={() => setActivePersona(i)}
                className="px-5 py-2 rounded-full border font-mono text-[10px] tracking-wider transition-all"
                style={{
                  color: activePersona === i ? '#fff' : '#7C6FA8',
                  borderColor: activePersona === i ? p.color : 'rgba(168,85,247,0.2)',
                  background: activePersona === i ? `linear-gradient(135deg,${p.color},${p.color}80)` : 'transparent',
                  boxShadow: activePersona === i ? `0 0 20px ${p.glow}` : 'none',
                }}>
                {p.name.split(' ')[0].toUpperCase()} — {p.id}
              </button>
            ))}
          </div>

          {PERSONAS.map((persona, i) => i === activePersona && (
            <div key={persona.id} className="grid md:grid-cols-3 gap-6">
              <div>
                <div className="relative overflow-hidden rounded-2xl mb-4" style={{ boxShadow: `0 0 40px ${persona.glow}` }}>
                  <img src={persona.photo} alt={`Portrait of ${persona.name}`} className="w-full object-cover" style={{ height: 280 }} />
                  <div className="absolute inset-0" style={{ background: `linear-gradient(to top,rgba(7,5,15,0.95) 0%,transparent 55%)` }} />
                  <div className="absolute bottom-4 left-4">
                    <p className="font-serif text-xl text-white">{persona.name}</p>
                    <p className="font-mono text-[9px] tracking-widest mt-1" style={{ color: persona.color }}>{persona.role.toUpperCase()}</p>
                  </div>
                </div>
                <div className="rounded-xl p-4 border space-y-2" style={{ background: `${persona.color}06`, borderColor: `${persona.color}20` }}>
                  {[['Age', String(persona.age)], ['Location', persona.location]].map(([k, v]) => (
                    <div key={k} className="flex justify-between text-sm border-b pb-2" style={{ borderColor: `${persona.color}15` }}>
                      <span className="text-[#7C6FA8]">{k}</span>
                      <span className="text-[#F0EDFF]">{v}</span>
                    </div>
                  ))}
                  <div className="pt-1">
                    <p className="font-mono text-[9px] text-[#7C6FA8] mb-2">DAILY TOOLS</p>
                    <div className="flex flex-wrap gap-1">
                      {persona.tools.map(t => <GlowBadge key={t} label={t} color={persona.color} />)}
                    </div>
                  </div>
                </div>
              </div>

              <div className="md:col-span-2 space-y-5">
                <blockquote className="rounded-xl p-6 border-l-4" style={{ background: `${persona.color}08`, borderColor: persona.color }}>
                  <p className="font-serif text-2xl italic font-light leading-snug" style={{ color: persona.color }}>{persona.quote}</p>
                </blockquote>

                <div className="grid grid-cols-2 gap-4">
                  <div className="rounded-xl p-5 border" style={{ background: `${LM}06`, borderColor: `${LM}25` }}>
                    <p className="font-mono text-[9px] tracking-wider mb-3" style={{ color: LM }}>GOALS</p>
                    <ul className="space-y-2">
                      {persona.goals.map(g => (
                        <li key={g} className="flex items-start gap-2 text-sm text-[#C4B5FD]">
                          <span className="mt-0.5 flex-shrink-0" style={{ color: LM }}>→</span>{g}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="rounded-xl p-5 border" style={{ background: 'rgba(239,68,68,0.05)', borderColor: 'rgba(239,68,68,0.2)' }}>
                    <p className="font-mono text-[9px] tracking-wider mb-3 text-red-400">FRUSTRATIONS</p>
                    <ul className="space-y-2">
                      {persona.frustrations.map(f => (
                        <li key={f} className="flex items-start gap-2 text-sm text-[#C4B5FD]">
                          <span className="mt-0.5 flex-shrink-0 text-red-400">✕</span>{f}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="rounded-xl p-5 border" style={{ background: `${C}08`, borderColor: `${C}30` }}>
                  <p className="font-mono text-[9px] tracking-wider mb-2" style={{ color: C }}>DESIGN IMPLICATION</p>
                  <p className="text-sm text-[#C4B5FD] leading-relaxed">
                    {i === 0 && 'Surface roadmap progress at a glance. Reduce clicks to status without a separate doc. Prioritise the weekly digest view.'}
                    {i === 1 && 'Lead with the "why." Every ticket must surface linked PRD and design frame. Keyboard shortcuts are table stakes.'}
                    {i === 2 && 'Figma plugin is the entry point, not an add-on. Component change tracking must be automatic. Comment threads follow the ticket.'}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </Section>

        {/* ── 03 JOURNEY ── */}
        <Section id="journey">
          <SectionLabel number="03" title="User Journey Map" color={CO} />
          <h2 className="font-serif text-4xl font-light mb-2 text-[#F0EDFF]">Maya's path from discovery to advocacy</h2>
          <p className="font-mono text-[10px] tracking-wider text-[#7C6FA8] mb-10">6 stages · 3 roles tracked · emotional arc mapped</p>

          <div className="overflow-x-auto rounded-xl border" style={{ borderColor: 'rgba(168,85,247,0.15)' }}>
            <div className="min-w-[900px]">
              <div className="grid grid-cols-6" style={{ background: 'rgba(168,85,247,0.05)' }}>
                {JOURNEY_STAGES.map((s, i) => (
                  <div key={s.stage} className="px-4 py-3 border-b border-r text-center" style={{ borderColor: 'rgba(168,85,247,0.1)' }}>
                    <p className="font-mono text-[9px] tracking-widest" style={{ color: [V, C, CO, PK, LM, V][i] }}>{s.stage.toUpperCase()}</p>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-6 border-b" style={{ borderColor: 'rgba(168,85,247,0.08)' }}>
                {JOURNEY_STAGES.map(s => (
                  <div key={s.stage} className="px-4 py-3 text-xs text-[#C4B5FD] border-r leading-relaxed" style={{ borderColor: 'rgba(168,85,247,0.08)', minHeight: 72 }}>{s.action}</div>
                ))}
              </div>
              {[
                { role: 'PM', key: 'pm' as const, color: V },
                { role: 'ENG', key: 'eng' as const, color: C },
                { role: 'DES', key: 'des' as const, color: PK },
              ].map(({ role, key, color }) => (
                <div key={role} className="grid grid-cols-6 border-b" style={{ borderColor: 'rgba(168,85,247,0.06)' }}>
                  {JOURNEY_STAGES.map(s => (
                    <div key={s.stage} className="px-4 py-3 border-r" style={{ borderColor: 'rgba(168,85,247,0.06)', minHeight: 72 }}>
                      <p className="font-mono text-[8px] mb-1" style={{ color }}>{role}</p>
                      <p className="text-[11px] text-[#7C6FA8] leading-relaxed">{s[key]}</p>
                    </div>
                  ))}
                </div>
              ))}
              <div className="grid grid-cols-6" style={{ background: 'rgba(7,5,15,0.5)' }}>
                {JOURNEY_STAGES.map((s, i) => (
                  <div key={i} className="px-4 py-3 border-r" style={{ borderColor: 'rgba(168,85,247,0.06)' }}>
                    <p className="font-mono text-[8px] text-[#7C6FA8] mb-2">MOOD</p>
                    <EmotionBar level={s.emotion} />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Arc bars */}
          <div className="mt-4 p-4 rounded-xl border flex items-end gap-1 h-24" style={{ background: 'rgba(168,85,247,0.04)', borderColor: 'rgba(168,85,247,0.12)' }}>
            {JOURNEY_STAGES.map((s, i) => {
              const c = s.emotion <= 2 ? '#EF4444' : s.emotion === 3 ? CO : s.emotion === 4 ? C : LM
              return (
                <div key={i} className="flex-1 flex flex-col justify-end items-center gap-1">
                  <div className="w-full rounded-t-md transition-all" style={{ height: `${(s.emotion / 5) * 64}px`, background: `linear-gradient(to top,${c}80,${c})` }} />
                  <span className="font-mono text-[7px] text-[#7C6FA8]">{s.stage.slice(0,3).toUpperCase()}</span>
                </div>
              )
            })}
          </div>
        </Section>

        {/* ── 04 WIREFRAMES ── */}
        <Section id="wireframes">
          <SectionLabel number="04" title="Wireframes" color={PK} />
          <h2 className="font-serif text-4xl font-light text-[#F0EDFF] mb-2">Lo-fidelity exploration</h2>
          <p className="text-sm text-[#7C6FA8] mb-8">3 rounds · 26 concepts · 4 survived</p>

          <div className="grid md:grid-cols-2 gap-4">
            {[
              { title: 'Navigation shell', desc: 'Persistent sidebar with collapsible project tree and global ⌘K trigger', color: V, shapes: 'nav' },
              { title: 'Dashboard layout', desc: 'Weekly pulse card grid with velocity bar and blocker list', color: C, shapes: 'dash' },
              { title: 'Ticket + spec pane', desc: 'Side-by-side ticket detail and embedded Figma frame with live annotations', color: PK, shapes: 'ticket' },
              { title: 'Roadmap timeline', desc: 'Quarterly swimlane with drag-to-reorder and dependency lines', color: CO, shapes: 'roadmap' },
            ].map((w, i) => (
              <div key={w.title} className="rounded-xl overflow-hidden border hover:scale-[1.01] transition-transform group"
                style={{ borderColor: `${w.color}25` }}>
                <div className="h-48 relative flex items-center justify-center p-4" style={{ background: `${w.color}06` }}>
                  {/* Mini wireframe sketches */}
                  {i === 0 && (
                    <div className="w-full h-full border border-dashed rounded-lg flex overflow-hidden" style={{ borderColor: `${w.color}30` }}>
                      <div className="w-1/4 border-r p-2 space-y-1.5 flex flex-col" style={{ borderColor: `${w.color}20`, background: `${w.color}05` }}>
                        <div className="h-4 w-4 rounded" style={{ background: `${w.color}40` }} />
                        {[65,45,70,55,40].map((pw,j) => <div key={j} className="h-2 rounded-sm" style={{ width:`${pw}%`,background:`${w.color}25` }} />)}
                      </div>
                      <div className="flex-1 p-2">
                        <div className="h-2.5 w-3/4 rounded mb-2" style={{ background:`${w.color}30` }} />
                        <div className="grid grid-cols-2 gap-1">
                          {[1,2,3,4].map(j => <div key={j} className="h-8 rounded" style={{ background:`${w.color}10` }} />)}
                        </div>
                      </div>
                    </div>
                  )}
                  {i === 1 && (
                    <div className="w-full h-full border border-dashed rounded-lg p-2 space-y-1.5" style={{ borderColor:`${w.color}30` }}>
                      <div className="grid grid-cols-4 gap-1 mb-2">
                        {[1,2,3,4].map(j => <div key={j} className="h-10 rounded" style={{ background:`${w.color}12` }} />)}
                      </div>
                      <div className="grid grid-cols-3 gap-1">
                        {[1,2,3].map(j => <div key={j} className="h-14 rounded" style={{ background:`${w.color}08` }} />)}
                      </div>
                    </div>
                  )}
                  {i === 2 && (
                    <div className="w-full h-full border border-dashed rounded-lg flex gap-1 p-2" style={{ borderColor:`${w.color}30` }}>
                      <div className="flex-1 space-y-1.5">
                        <div className="h-2.5 rounded w-3/4" style={{ background:`${w.color}30` }} />
                        {[75,60,80,55,70].map((pw,j) => <div key={j} className="h-1.5 rounded-sm" style={{ width:`${pw}%`,background:`${w.color}18` }} />)}
                      </div>
                      <div className="w-px" style={{ background:`${w.color}25` }} />
                      <div className="flex-1 rounded border" style={{ background:`${w.color}05`,borderColor:`${w.color}20` }} />
                    </div>
                  )}
                  {i === 3 && (
                    <div className="w-full h-full border border-dashed rounded-lg p-3" style={{ borderColor:`${w.color}30` }}>
                      <div className="grid grid-cols-4 gap-1 mb-2">
                        {['Q1','Q2','Q3','Q4'].map(q => <div key={q} className="text-center font-mono text-[8px]" style={{ color:`${w.color}80` }}>{q}</div>)}
                      </div>
                      {[1,2,3,4].map(row => (
                        <div key={row} className="flex items-center gap-1 mb-2">
                          <div className="w-8 h-2 rounded-full" style={{ background:`${w.color}15` }} />
                          <div className="flex-1 h-4 rounded relative" style={{ background:`${w.color}05` }}>
                            <div className="absolute h-4 rounded" style={{ left:`${row*8}%`,width:`${45-row*5}%`,background:`${w.color}30` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="absolute top-3 left-3">
                    <span className="font-mono text-[8px] px-1.5 py-0.5 rounded" style={{ color: w.color, background:`${w.color}15` }}>WF-{String(i+1).padStart(2,'0')}</span>
                  </div>
                </div>
                <div className="p-4" style={{ background:'rgba(15,11,30,0.8)' }}>
                  <h3 className="font-serif text-lg mb-1" style={{ color: w.color }}>{w.title}</h3>
                  <p className="text-xs text-[#7C6FA8]">{w.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* ── 05 DESIGN SYSTEM ── */}
        <Section id="system">
          <SectionLabel number="05" title="Flux Design Language" color={LM} />
          <h2 className="font-serif text-4xl font-light text-[#F0EDFF] mb-8">Design system</h2>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            {/* Colors */}
            <div>
              <p className="font-mono text-[9px] tracking-widest text-[#7C6FA8] mb-4">COLOUR TOKENS</p>
              <div className="space-y-2">
                {COLORS.map(c => (
                  <div key={c.name} className="flex items-center gap-3 rounded-lg px-3 py-2 hover:bg-[rgba(168,85,247,0.05)] transition-colors">
                    <div className="w-8 h-8 rounded-md flex-shrink-0 border" style={{ background: c.hex, borderColor: 'rgba(255,255,255,0.1)' }} />
                    <div className="flex-1 flex justify-between">
                      <span className="text-sm text-[#F0EDFF]">{c.name}</span>
                      <span className="font-mono text-xs text-[#7C6FA8]">{c.role}</span>
                    </div>
                    <span className="font-mono text-[9px] text-[#7C6FA8]">{c.hex}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Type */}
            <div>
              <p className="font-mono text-[9px] tracking-widest text-[#7C6FA8] mb-4">TYPE SCALE</p>
              <div className="space-y-4">
                {TYPE_SCALE.map(t => (
                  <div key={t.label} className="border-b pb-4" style={{ borderColor: 'rgba(168,85,247,0.1)' }}>
                    <div className="flex justify-between mb-1">
                      <span className="font-mono text-[9px] text-[#7C6FA8]">{t.label}</span>
                      <span className="font-mono text-[9px] text-[#7C6FA8]">{t.size}px · {t.family}</span>
                    </div>
                    <p className="text-[#F0EDFF] truncate"
                      style={{ fontFamily: t.family, fontSize: Math.min(t.size, 32) + 'px', fontWeight: t.weight, fontStyle: t.style }}>
                      {t.sample}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Component samples */}
          <p className="font-mono text-[9px] tracking-widest text-[#7C6FA8] mb-4">COMPONENT LIBRARY</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="rounded-xl p-4 border space-y-3" style={{ background:'rgba(15,11,30,0.8)',borderColor:'rgba(168,85,247,0.2)' }}>
              <p className="font-mono text-[9px] text-[#7C6FA8]">BUTTONS</p>
              <button className="w-full py-2 px-3 text-xs font-medium rounded-lg transition-all hover:opacity-90" style={{ background:`linear-gradient(135deg,${V},${C})`,color:'#fff' }}>Primary</button>
              <button className="w-full py-2 px-3 text-xs font-medium rounded-lg border transition-all hover:bg-[rgba(168,85,247,0.1)]" style={{ borderColor:`${V}50`,color:V }}>Secondary</button>
              <button className="w-full py-2 px-3 text-xs font-medium rounded-lg transition-all hover:text-white" style={{ color:'#7C6FA8' }}>Ghost</button>
            </div>
            <div className="rounded-xl p-4 border space-y-2" style={{ background:'rgba(15,11,30,0.8)',borderColor:'rgba(168,85,247,0.2)' }}>
              <p className="font-mono text-[9px] text-[#7C6FA8] mb-3">STATUS</p>
              {[
                {label:'In Progress',c:V},{label:'Shipped',c:LM},{label:'Blocked',c:'#EF4444'},{label:'Backlog',c:'#7C6FA8'},
              ].map(s => (
                <span key={s.label} className="inline-block font-mono text-[9px] px-2 py-1 mr-1 mb-1 rounded-full border"
                  style={{ color:s.c,borderColor:`${s.c}40`,background:`${s.c}10` }}>{s.label}</span>
              ))}
            </div>
            <div className="rounded-xl p-4 border space-y-3" style={{ background:'rgba(15,11,30,0.8)',borderColor:'rgba(168,85,247,0.2)' }}>
              <p className="font-mono text-[9px] text-[#7C6FA8]">AVATARS</p>
              <div className="flex -space-x-2">
                {[V,C,PK,CO].map((col,i) => (
                  <div key={i} className="w-9 h-9 rounded-full border-2 flex items-center justify-center text-xs font-bold"
                    style={{ background:`linear-gradient(135deg,${col},${col}80)`,borderColor:'#0F0B1E',color:'#fff' }}>
                    {['M','D','P','J'][i]}
                  </div>
                ))}
                <div className="w-9 h-9 rounded-full border-2 flex items-center justify-center font-mono text-[8px]"
                  style={{ background:'rgba(168,85,247,0.15)',borderColor:'#0F0B1E',color:'#7C6FA8' }}>+3</div>
              </div>
            </div>
            <div className="rounded-xl p-4 border space-y-3" style={{ background:'rgba(15,11,30,0.8)',borderColor:'rgba(168,85,247,0.2)' }}>
              <p className="font-mono text-[9px] text-[#7C6FA8]">INPUTS</p>
              <div className="rounded-lg border px-3 py-2 flex items-center gap-2" style={{ background:'rgba(168,85,247,0.06)',borderColor:`${V}30` }}>
                <span className="font-mono text-[10px]" style={{ color:V }}>⌘K</span>
                <span className="text-xs text-[#7C6FA8]">Search anything…</span>
              </div>
              <div className="border-b pb-1" style={{ borderColor:`${V}40` }}>
                <input placeholder="Ticket title" className="w-full bg-transparent text-xs text-[#F0EDFF] outline-none placeholder:text-[#7C6FA8]" />
              </div>
            </div>
          </div>
        </Section>

        {/* ── 06 HI-FI ── */}
        <Section id="hifi">
          <SectionLabel number="06" title="High-Fidelity Screens" color={C} />

          <div className="flex gap-2 mb-6 flex-wrap">
            {HIFI_SCREENS.map((s, i) => (
              <button key={s.id} onClick={() => setActiveScreen(i)}
                className="font-mono text-[10px] tracking-widest px-4 py-2 rounded-full border transition-all"
                style={{
                  color: activeScreen === i ? '#fff' : '#7C6FA8',
                  borderColor: activeScreen === i ? s.accent : 'rgba(168,85,247,0.2)',
                  background: activeScreen === i ? s.accent : 'transparent',
                  boxShadow: activeScreen === i ? `0 0 16px ${s.accent}50` : 'none',
                }}>
                {s.tag}
              </button>
            ))}
          </div>

          {HIFI_SCREENS.map((screen, i) => i === activeScreen && (
            <div key={screen.id}>
              <div className="rounded-2xl overflow-hidden border mb-4" style={{ border:`1px solid ${screen.accent}30`, boxShadow:`0 0 60px ${screen.accent}15` }}>
                <div className="flex items-center gap-2 px-4 py-3 border-b" style={{ background:'rgba(0,0,0,0.4)',borderColor:`${screen.accent}15` }}>
                  <div className="flex gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500 opacity-70" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500 opacity-70" />
                    <div className="w-3 h-3 rounded-full bg-green-500 opacity-70" />
                  </div>
                  <div className="flex-1 mx-4 rounded px-3 h-5 flex items-center" style={{ background:'rgba(255,255,255,0.04)' }}>
                    <span className="font-mono text-[9px] text-[rgba(255,255,255,0.3)]">app.flux.io/{screen.tag.toLowerCase()}</span>
                  </div>
                </div>
                <div className="flex h-72" style={{ background: screen.bg }}>
                  <div className="w-48 border-r flex flex-col p-3 gap-1.5" style={{ borderColor:`${screen.accent}15`,background:'rgba(0,0,0,0.25)' }}>
                    <div className="w-8 h-8 rounded-lg mb-3 flex items-center justify-center font-bold text-sm" style={{ background:`linear-gradient(135deg,${screen.accent},${screen.accent}70)`,color:'#fff' }}>F</div>
                    {['Dashboard','Roadmap','Tickets','Design','Team','Settings'].map((item, j) => (
                      <div key={item} className="flex items-center gap-2 px-2 py-1.5 rounded-md" style={{ background: j === i % 6 ? `${screen.accent}20` : 'transparent' }}>
                        <div className="w-3 h-3 rounded-sm" style={{ background: j === i % 6 ? screen.accent : 'rgba(255,255,255,0.1)' }} />
                        <span className="font-mono text-[9px]" style={{ color: j === i % 6 ? screen.accent : 'rgba(255,255,255,0.35)' }}>{item}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex-1 p-5">
                    <div className="flex justify-between mb-4">
                      <div>
                        <p className="font-mono text-[9px] mb-1" style={{ color: screen.accent }}>SCREEN_{String(i+1).padStart(2,'0')}</p>
                        <p className="font-serif text-lg text-white">{screen.title}</p>
                      </div>
                      <button className="px-3 py-1 rounded-md text-xs font-medium" style={{ background:`linear-gradient(135deg,${screen.accent},${screen.accent}70)`,color:'#fff' }}>+ New</button>
                    </div>
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      {[['74%','Velocity'],['3','Blockers'],['12','Shipped']].map(([val,lbl]) => (
                        <div key={lbl} className="p-3 rounded-xl border" style={{ background:'rgba(0,0,0,0.3)',borderColor:`${screen.accent}20` }}>
                          <p className="font-serif text-2xl" style={{ color: screen.accent }}>{val}</p>
                          <p className="font-mono text-[8px] text-[rgba(255,255,255,0.3)]">{lbl.toUpperCase()}</p>
                        </div>
                      ))}
                    </div>
                    <div className="space-y-2">
                      {[90,65,80,45,70].map((w,j) => (
                        <div key={j} className="flex items-center gap-2">
                          <div className="w-20 h-1.5 rounded-full overflow-hidden" style={{ background:'rgba(255,255,255,0.06)' }}>
                            <div className="h-full rounded-full" style={{ width:`${w}%`,background:`linear-gradient(to right,${screen.accent}80,${screen.accent})` }} />
                          </div>
                          <div className="h-1.5 flex-1 rounded-full" style={{ background:'rgba(255,255,255,0.04)' }} />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex-1">
                  <h3 className="font-serif text-xl text-[#F0EDFF] mb-1">{screen.title}</h3>
                  <p className="text-sm text-[#C4B5FD]">{screen.desc}</p>
                </div>
                <span className="font-mono text-[9px] px-3 py-1.5 rounded-full flex-shrink-0" style={{ color: screen.accent, background:`${screen.accent}15`, border:`1px solid ${screen.accent}30` }}>{screen.tag}</span>
              </div>
            </div>
          ))}
        </Section>

        {/* ── 07 PROTOTYPE ── */}
        <Section id="prototype">
          <SectionLabel number="07" title="Interactive Prototype" color={PK} />
          <h2 className="font-serif text-4xl font-light text-[#F0EDFF] mb-2">Ticket creation flow</h2>
          <p className="text-sm text-[#7C6FA8] mb-8">4-step walkthrough · 8 usability participants · 89% task completion</p>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-2">
              {[
                { step: 1, title: 'Open command palette', desc: 'Trigger ⌘K from any screen', color: V },
                { step: 2, title: 'Describe intent', desc: 'Natural language or template picker', color: C },
                { step: 3, title: 'Link spec', desc: 'Figma frame auto-suggested from branch', color: PK },
                { step: 4, title: 'Assign & create', desc: 'Assignee, priority, sprint in one step', color: LM },
              ].map(s => (
                <button key={s.step} onClick={() => setProtoStep(s.step - 1)}
                  className="w-full text-left p-4 rounded-xl border transition-all hover:scale-[1.01]"
                  style={{
                    background: protoStep === s.step - 1 ? `${s.color}12` : 'rgba(15,11,30,0.6)',
                    borderColor: protoStep === s.step - 1 ? s.color : 'rgba(168,85,247,0.15)',
                    boxShadow: protoStep === s.step - 1 ? `0 0 20px ${s.color}20` : 'none',
                  }}>
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-full flex items-center justify-center font-mono text-[10px] font-bold flex-shrink-0"
                      style={{ background: protoStep === s.step - 1 ? s.color : 'rgba(168,85,247,0.15)', color: protoStep === s.step - 1 ? '#fff' : '#7C6FA8' }}>
                      {s.step}
                    </div>
                    <div>
                      <p className="text-sm font-medium" style={{ color: protoStep === s.step - 1 ? s.color : '#F0EDFF' }}>{s.title}</p>
                      <p className="text-xs text-[#7C6FA8]">{s.desc}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            <div className="md:col-span-2 rounded-2xl overflow-hidden border" style={{ background:'#070512',borderColor:'rgba(168,85,247,0.2)',boxShadow:'0 0 40px rgba(168,85,247,0.1)' }}>
              <div className="flex items-center gap-2 px-4 py-2.5 border-b" style={{ borderColor:'rgba(168,85,247,0.12)' }}>
                <div className="flex gap-1.5">
                  {['#EF4444','#F59E0B','#22C55E'].map(c => <div key={c} className="w-2.5 h-2.5 rounded-full opacity-60" style={{ background:c }} />)}
                </div>
                <span className="font-mono text-[9px] text-[#7C6FA8] ml-2">PROTOTYPE — STEP {protoStep+1} / 4</span>
              </div>

              <div className="p-8 h-64 flex items-center justify-center">
                {protoStep === 0 && (
                  <div className="w-full max-w-sm">
                    <div className="rounded-xl border p-4" style={{ background:'rgba(168,85,247,0.08)',borderColor:`${V}40` }}>
                      <div className="flex items-center gap-3 mb-3 pb-3 border-b" style={{ borderColor:`${V}20` }}>
                        <div className="px-2 py-0.5 rounded text-[9px] font-mono" style={{ background:`${V}20`,color:V }}>⌘K</div>
                        <span className="text-sm text-[#7C6FA8]">What do you need?</span>
                      </div>
                      {['✦ New ticket','🗺 Open roadmap','🔍 Search tickets','👥 Invite teammate'].map(item => (
                        <div key={item} className="py-2 px-2 rounded-md text-sm text-[#C4B5FD] hover:bg-[rgba(168,85,247,0.1)] cursor-pointer flex justify-between group">
                          <span>{item}</span>
                          <span className="font-mono text-[9px] text-[#7C6FA8] opacity-0 group-hover:opacity-100">↵</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {protoStep === 1 && (
                  <div className="w-full max-w-sm">
                    <div className="rounded-xl border p-5" style={{ background:`${C}08`,borderColor:`${C}40` }}>
                      <div className="flex items-center gap-2 mb-4">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-sm" style={{ background:C }}>+</div>
                        <span className="font-mono text-[10px]" style={{ color:C }}>NEW TICKET</span>
                      </div>
                      <input className="w-full bg-transparent text-sm text-[#F0EDFF] outline-none border-b pb-2 mb-4 placeholder:text-[#7C6FA8]"
                        style={{ borderColor:`${C}30` }} placeholder="Describe what needs done…" defaultValue="Implement dark mode toggle" />
                      <div className="flex gap-2 flex-wrap">
                        {['Bug','Feature','Research','Chore'].map(t => (
                          <span key={t} className="font-mono text-[9px] px-2 py-1 rounded-full border cursor-pointer hover:border-current" style={{ borderColor:'rgba(6,182,212,0.3)',color:C }}>{t}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
                {protoStep === 2 && (
                  <div className="w-full max-w-sm">
                    <div className="rounded-xl border p-4" style={{ background:`${PK}08`,borderColor:`${PK}40` }}>
                      <p className="font-mono text-[9px] tracking-wider mb-3" style={{ color:PK }}>SUGGESTED SPECS</p>
                      <div className="rounded-lg border p-3 mb-2 flex items-center gap-3 cursor-pointer hover:border-[rgba(236,72,153,0.6)] transition-colors" style={{ borderColor:`${PK}35`,background:`${PK}05` }}>
                        <div className="w-10 h-10 rounded-lg flex-shrink-0 flex items-center justify-center font-bold" style={{ background:`${PK}20`,color:PK }}>F</div>
                        <div className="flex-1">
                          <p className="text-xs text-[#F0EDFF]">Dark mode — component spec</p>
                          <p className="font-mono text-[9px] text-[#7C6FA8]">Figma · updated 2h ago</p>
                        </div>
                        <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px]" style={{ background:LM,color:'#000' }}>✓</div>
                      </div>
                      <div className="rounded-lg border p-3 flex items-center gap-3 opacity-40" style={{ borderColor:'rgba(255,255,255,0.1)' }}>
                        <div className="w-10 h-10 rounded-lg flex-shrink-0" style={{ background:'rgba(255,255,255,0.05)' }} />
                        <p className="text-xs text-[#7C6FA8]">PRD — theming v2.docx</p>
                      </div>
                    </div>
                  </div>
                )}
                {protoStep === 3 && (
                  <div className="w-full max-w-sm">
                    <div className="rounded-xl border p-5" style={{ background:`${LM}06`,borderColor:`${LM}40` }}>
                      <div className="flex items-center gap-2 mb-4">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold" style={{ background:LM,color:'#000' }}>✓</div>
                        <span className="font-mono text-[10px]" style={{ color:LM }}>READY TO CREATE</span>
                      </div>
                      <div className="space-y-2 mb-5">
                        {[['Title','Implement dark mode toggle'],['Type','Feature'],['Assignee','Priya S.'],['Sprint','Q4 — Week 3'],['Spec','Figma: Dark mode comp']].map(([k,v]) => (
                          <div key={k} className="flex justify-between text-xs border-b pb-1.5" style={{ borderColor:'rgba(255,255,255,0.05)' }}>
                            <span className="text-[#7C6FA8]">{k}</span>
                            <span className="text-[#F0EDFF]">{v}</span>
                          </div>
                        ))}
                      </div>
                      <button className="w-full py-2.5 rounded-lg text-sm font-semibold transition-all hover:opacity-90"
                        style={{ background:`linear-gradient(135deg,${LM},#22C55E)`,color:'#000' }}>Create ticket →</button>
                    </div>
                  </div>
                )}
              </div>

              <div className="px-6 pb-4 flex gap-1.5">
                {[0,1,2,3].map(i => (
                  <button key={i} onClick={() => setProtoStep(i)} className="flex-1 h-1 rounded-full transition-all"
                    style={{ background: i <= protoStep ? `linear-gradient(to right,${V},${C})` : 'rgba(168,85,247,0.15)' }} />
                ))}
              </div>
            </div>
          </div>
        </Section>

        {/* ── 08 OUTCOMES ── */}
        <Section id="outcomes">
          <SectionLabel number="08" title="Outcomes & Impact" color={LM} />

          <div className="grid md:grid-cols-2 gap-10 mb-10">
            <div>
              <h2 className="font-serif text-4xl font-light text-[#F0EDFF] mb-4">Pilot results</h2>
              <p className="text-sm text-[#C4B5FD] leading-relaxed mb-6">
                6 product teams (38 participants) over 8 weeks. Pre/post measured on the same methodology as our initial research benchmarks.
              </p>
              <img
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=280&fit=crop&auto=format"
                alt="Analytics dashboard showing product metrics"
                className="w-full object-cover rounded-xl"
                style={{ height: 180, filter:'brightness(0.6) saturate(0.7)' }}
              />
            </div>

            <div className="space-y-3">
              {METRICS.map((m, i) => {
                const colors = [V, C, PK, CO, LM]
                const col = colors[i % colors.length]
                return (
                  <div key={m.label} className="rounded-xl border p-4" style={{ background:`${col}06`,borderColor:`${col}20` }}>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-[#F0EDFF]">{m.label}</span>
                      <span className="font-mono text-sm font-medium" style={{ color: LM }}>{m.delta}</span>
                    </div>
                    <div className="h-2 rounded-full overflow-hidden mb-2" style={{ background:'rgba(255,255,255,0.06)' }}>
                      <div className="h-full rounded-full transition-all" style={{ width:`${m.pct}%`,background:`linear-gradient(to right,${col}80,${col})` }} />
                    </div>
                    <div className="flex justify-between font-mono text-[9px] text-[#7C6FA8]">
                      <span>Before: {m.before}</span>
                      <span style={{ color: col }}>After: {m.after}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-4 mb-12">
            {[
              { title: 'What worked', items: ['Single-pane ticket + spec view', 'Command palette discoverability', 'PR ↔ ticket auto-linking', 'Async digest notifications'], color: LM, icon: '✦' },
              { title: 'What we changed', items: ['Removed inline Figma editor', 'Replaced sidebar with top rail on mobile', 'Added "why" field to ticket templates', 'Made sprint assignment optional'], color: CO, icon: '↺' },
              { title: 'Next steps', items: ['AI-generated ticket summaries', 'Org-wide roadmap read view', 'Slack thread ↔ ticket sync', 'Component usage analytics'], color: C, icon: '→' },
            ].map(c => (
              <div key={c.title} className="rounded-xl p-5 border" style={{ background:`${c.color}06`,borderColor:`${c.color}25` }}>
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-lg" style={{ color:c.color }}>{c.icon}</span>
                  <p className="font-mono text-[9px] tracking-wider" style={{ color:c.color }}>{c.title.toUpperCase()}</p>
                </div>
                <ul className="space-y-2">
                  {c.items.map(item => (
                    <li key={item} className="flex items-start gap-2 text-sm text-[#C4B5FD]">
                      <div className="w-4 h-4 rounded flex items-center justify-center flex-shrink-0 mt-0.5 text-[9px]" style={{ background:`${c.color}20`,color:c.color }}>✓</div>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="rounded-2xl p-8 text-center relative overflow-hidden" style={{ background:'linear-gradient(135deg,#1a0533 0%,#050d2e 50%,#001a1a 100%)' }}>
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-0 left-1/3 w-64 h-64 rounded-full" style={{ background:'radial-gradient(circle,rgba(168,85,247,0.2) 0%,transparent 70%)',filter:'blur(30px)' }} />
              <div className="absolute bottom-0 right-1/3 w-48 h-48 rounded-full" style={{ background:'radial-gradient(circle,rgba(6,182,212,0.15) 0%,transparent 70%)',filter:'blur(30px)' }} />
            </div>
            <p className="font-mono text-[9px] tracking-[0.3em] text-[#7C6FA8] mb-3">CASE STUDY COMPLETE</p>
            <h2 className="font-serif text-5xl font-light italic mb-4"
              style={{ background:`linear-gradient(135deg,#F0EDFF,${V},${C})`,WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',backgroundClip:'text' }}>
              One tool, one truth.
            </h2>
            <p className="text-sm text-[#C4B5FD] mb-2">Lead Designer · 14 weeks · 2024</p>
            <p className="font-mono text-[9px] text-[#7C6FA8]">18 interviews · 214 survey respondents · 47 screens · +70 NPS</p>
          </div>
        </Section>
      </main>
    </div>
  )
}
